﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MyProject_1
{
    public partial class AddSemester : Form
    {
        public AddSemester()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        { 
            
            String sn = textBox1.Text;
           
            if (String.IsNullOrEmpty(sn))
            {
                MessageBox.Show("your Boxs are Empty");
                return;
            }

            SqlConnection con = new SqlConnection(App.connectionString);

             con.Open();
            SqlCommand cmd = new SqlCommand("insert into semester VALUES(@Name,@StartDate,@EndDate );",con);

            cmd.Parameters.AddWithValue("@Name", textBox1.Text.ToString());
            cmd.Parameters.AddWithValue("@StartDate", this.dateTimePicker1.Text);
            cmd.Parameters.AddWithValue("@EndDate", this.dateTimePicker2.Text);


            cmd.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("Information of this AddClass is updated!");

           
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
            this.Close();
            
        }
    }
}
