﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MyProject_1
{
    public partial class AddStudent : Form
    {
        public AddStudent()
        {
            InitializeComponent();
            SqlDataAdapter sqlDA = new SqlDataAdapter("select * from Class ", App.connectionString);
            DataSet ds = new DataSet();
            //copy db to ds
            sqlDA.Fill(ds, "Class");
            //copy data from ds.table["semester"] to control
            comboBox1.DataSource = ds.Tables["Class"];
            comboBox1.DisplayMember = "ClassCode";
            comboBox1.ValueMember = "ClassCode";
          
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                String rn = textBox1.Text;
                // String ccd = comboBox1.Text;
                String fn = textBox2.Text;
                // String na = comboBox2.Text;
                if (String.IsNullOrEmpty(rn) || String.IsNullOrEmpty(fn))
                {
                    MessageBox.Show("your Boxs are Empty");
                    return;
                }
                else
                {


                   SqlConnection sqlconn = new SqlConnection
                (App.connectionString);
                sqlconn.Open();

                //setup sql statement
                string sqlInsert = "insert into Student values (@RollNo, @classcode,@FullName,@Nationality) ";
                SqlCommand sqlCmd = new SqlCommand(sqlInsert, sqlconn);

                //specify values for parameters
                sqlCmd.Parameters.AddWithValue("@RollNo", textBox1.Text);
                sqlCmd.Parameters.AddWithValue("@classcode", comboBox1.SelectedValue.ToString());
                sqlCmd.Parameters.AddWithValue("@FullName", textBox2.Text);
                sqlCmd.Parameters.AddWithValue("@Nationality", comboBox2.SelectedItem.ToString());

                //send and recieve result from db
                sqlCmd.ExecuteNonQuery(); //delete, update, insert
                MessageBox.Show("Information of Student has been added");


                sqlconn.Close();


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
