﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;


namespace MyProject_1
{
    public partial class FilterStudent : Form
    {
        public FilterStudent()
        {
            InitializeComponent();
            SqlDataAdapter sda = new SqlDataAdapter("Select * from semester", App.connectionString);
            DataSet ds = new DataSet();
            sda.Fill(ds, "semester");
           comboBox3.DataSource = ds.Tables["semester"];
            comboBox3.DisplayMember = "semesterNo";
            comboBox3.ValueMember = "Id";

        }

        private void studentStatusBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.studentStatusBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dataSet1);

        }

        private void FilterStudent_Load(object sender, EventArgs e)
        {
            
            this.studentStatusTableAdapter.Fill(this.dataSet1.StudentStatus);

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            string majorS = "";
            if (radioButton3.Checked)
                majorS = "ISE";
            else if (radioButton4.Checked)
                majorS = "IBA";

            string TheCommand = "select Student.RollNo, Student.ClassCode, Student.FullName, Student.Nationality, Class.Batch, Class.Major, Semester.Name, StudentStatus.SemesterNo, StudentStatus.Status " +
                "from Student, Class, Semester, StudentStatus " +
                "where StudentStatus.RollNo = Student.RollNo " +
                "and StudentStatus.SemesterId = Semester.Id " +
                "and Student.ClassCode = Class.ClassCode " +
                    " AND (Class.Major='" + majorS.ToString() + "'  AND StudentStatus.SemesterNo = '" + comboBox3.Text.ToString() + "'" +
                   "AND StudentStatus.Status='" + comboBox2.Text.ToString() + "' )";
            SqlConnection MyConnection = new SqlConnection(App.connectionString);
            SqlDataAdapter MyDataAdapter = new SqlDataAdapter(TheCommand, MyConnection);

            DataSet MyDataSet = new DataSet();
            MyConnection.Open();
           MyDataAdapter.Fill(MyDataSet, "FilterTable");
            MyConnection.Close();
            dataGridView1.DataSource = MyDataSet;
            dataGridView1.DataMember = "FilterTable";

            int Count_row = dataGridView1.Rows.Count - 1;
            label7.Text = "Total Student (s): " + Count_row.ToString();
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            string majorS = "";
            if (radioButton3.Checked)
                majorS = "ISE";
            else if (radioButton4.Checked)
                majorS = "IBA";

            string TheCommand = "select Student.RollNo, Student.ClassCode, Student.FullName, Student.Nationality, Class.Batch, Class.Major, Semester.Name, StudentStatus.SemesterNo, StudentStatus.Status " +
                "from Student, Class, Semester, StudentStatus " +
                "where StudentStatus.RollNo = Student.RollNo " +
                "and StudentStatus.SemesterId = Semester.Id " +
                "and Student.ClassCode = Class.ClassCode " +
                    " AND (Class.Major='" + majorS.ToString() + "'  AND StudentStatus.SemesterNo = '" + comboBox3.Text.ToString() + "'" +
                   "AND StudentStatus.Status='" + comboBox2.Text.ToString() + "' )";
            SqlConnection MyConnection = new SqlConnection(App.connectionString);
            SqlDataAdapter MyDataAdapter = new SqlDataAdapter(TheCommand, MyConnection);

            DataSet MyDataSet = new DataSet();
            MyConnection.Open();
             MyDataAdapter.Fill(MyDataSet, "FilterTable");
            MyConnection.Close();
            dataGridView1.DataSource = MyDataSet;
            dataGridView1.DataMember = "FilterTable";

            int Count_row = dataGridView1.Rows.Count - 1;
            label7.Text = "Total Student (s): " + Count_row.ToString();
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            string majorS = "";
            if (radioButton3.Checked)
                majorS = "ISE";
            else if (radioButton4.Checked)
                majorS = "IBA";

            string TheCommand = "select Student.RollNo, Student.ClassCode, Student.FullName, Student.Nationality, Class.Batch, Class.Major, Semester.Name, StudentStatus.SemesterNo, StudentStatus.Status " +
                "from Student, Class, Semester, StudentStatus " +
                "where StudentStatus.RollNo = Student.RollNo " +
                "and StudentStatus.SemesterId = Semester.Id " +
                "and Student.ClassCode = Class.ClassCode " +
                    " AND (Class.Major='" + majorS.ToString() + "'  AND StudentStatus.SemesterNo = '" + comboBox3.Text.ToString() + "'" +
                   "AND StudentStatus.Status='" + comboBox2.Text.ToString() + "' )";
            SqlConnection MyConnection = new SqlConnection(App.connectionString);
            SqlDataAdapter MyDataAdapter = new SqlDataAdapter(TheCommand, MyConnection);

            DataSet MyDataSet = new DataSet();
            MyConnection.Open();
            MyDataAdapter.Fill(MyDataSet, "FilterTable");
            MyConnection.Close();
            dataGridView1.DataSource = MyDataSet;
            dataGridView1.DataMember = "FilterTable";

            int Count_row = dataGridView1.Rows.Count - 1;
            label7.Text = "Total Student (s): " + Count_row.ToString();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string majorS = "";
            if (radioButton3.Checked)
                majorS = "ISE";
            else if (radioButton4.Checked)
                majorS = "IBA";

            string TheCommand = "select Student.RollNo, Student.ClassCode, Student.FullName, Student.Nationality, Class.Batch, Class.Major, Semester.Name, StudentStatus.SemesterNo, StudentStatus.Status " +
                "from Student, Class, Semester, StudentStatus " +
                "where StudentStatus.RollNo = Student.RollNo " +
                "and StudentStatus.SemesterId = Semester.Id " +
                "and Student.ClassCode = Class.ClassCode " +
                    " AND (Class.Major='" + majorS.ToString() + "'  AND StudentStatus.SemesterNo = '" + comboBox3.Text.ToString() + "'" +
                   "AND StudentStatus.Status='" + comboBox2.Text.ToString() + "' )";
            SqlConnection MyConnection = new SqlConnection(App.connectionString);
            SqlDataAdapter MyDataAdapter = new SqlDataAdapter(TheCommand, MyConnection);

            DataSet MyDataSet = new DataSet();
            MyConnection.Open();
          MyDataAdapter.Fill(MyDataSet, "FilterTable");
            MyConnection.Close();
            dataGridView1.DataSource = MyDataSet;
            dataGridView1.DataMember = "FilterTable";

            int Count_row = dataGridView1.Rows.Count - 1;
            label7.Text = "Total Student (s): " + Count_row.ToString();

            
        }

        private void button1_Click(object sender, EventArgs e)
        {

           
        }

    }

}
