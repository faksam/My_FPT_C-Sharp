﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyProject_1
{
    class App
    {
        public static string connectionString
        {
            get
            {
                return @"Data Source=IBRAHIM;Initial Catalog=StudentDB;Integrated Security=True";
            }
        }
    }
}
