﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MainProject
{
    class App
    {
        public static string connectionApp
        {
            get
            {
                return @" data source=IBRAHIM; database=StudentDB; integrated security=true;";
            }
        } 
    }
}
