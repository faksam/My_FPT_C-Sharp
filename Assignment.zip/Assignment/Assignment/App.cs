﻿using System;
using System.Collections.Generic;
using System.Web;

namespace Assignment
{
    public class App
    {
        public static string ConnectionString
        {
            get
            {
                return @"data source=FABULOUS; database=StudentDB; integrated security=true;";
            }
        }
    }
}